import { Component } from '@angular/core';

@Component({
  selector: 'app-not',
  templateUrl: './not.component.html',
  styleUrls: ['./not.component.css']
})
export class NotComponent {

}
